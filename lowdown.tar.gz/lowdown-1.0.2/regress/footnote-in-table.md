
first[^pt0]

a  | c
---|---
9  | foo[^pt1][^pt2]

Now[^pt3]

[^pt0]: one

[^pt1]: two

[^pt2]: three

    hello

    - world

[^pt3]: four
