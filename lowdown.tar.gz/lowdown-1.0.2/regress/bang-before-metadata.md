foo: bar

This is a test![%foo]
