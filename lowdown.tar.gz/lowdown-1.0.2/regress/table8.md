
| f\|oo \|
| ------ |
| b az |
| b  im |
