- 3 spaces
* 3 spaces
1. 3 spaces
2. 3 spaces

a

10. 4 spaces

b

100. 5 spaces
100. 5 spaces

     still 5 spaces
