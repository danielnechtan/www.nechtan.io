Darmok and Jalad...\
at Tanagra.
