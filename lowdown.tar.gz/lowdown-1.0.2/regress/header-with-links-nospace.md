
# a https://foo.com now[world](https://bar.com)bc

c
