1/4 of this
