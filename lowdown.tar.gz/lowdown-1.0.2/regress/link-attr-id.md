
link[text](address){ #www }tail
