Blah:

 - **--foo-bar**
 - **\-\-foo-bar**
