Hi.[^asdf]

[^pt]:
    Klingon insult, meaning something like "weirdo," deriving from
    the verb "to be weird" (**taQ**), with and [sic] you (plural)
    imperative prefix (**pe-**).

