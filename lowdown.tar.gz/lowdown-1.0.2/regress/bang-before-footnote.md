
This is a test![^01]

[^01]: footnote text.
