I have '1/4th' of this.
