
link [text](address) { .cls }
