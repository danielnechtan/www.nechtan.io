
not:a link $shor maths

not a wwwlink2 or @email
