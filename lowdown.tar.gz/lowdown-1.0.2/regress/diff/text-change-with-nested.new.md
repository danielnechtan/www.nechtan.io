
Hello, *world [shmagain](https://foo.com) cdef*.
