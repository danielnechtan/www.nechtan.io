
not:a link $or maths

not a wwwlink or @email
