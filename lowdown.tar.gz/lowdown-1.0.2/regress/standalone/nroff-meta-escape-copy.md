copyright: .ab~cdes*()&)abc
.fgh

foo bar
