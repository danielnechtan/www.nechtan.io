An initial paragraph.

- An outer list.

  With a paragraph.

  1. An inner ordered list.
  2. That's inline.
  3. Followed by...

  -  An inner regular lits.

     With inner paragraph.

  Another paragraph.

A last outer paragraph.
