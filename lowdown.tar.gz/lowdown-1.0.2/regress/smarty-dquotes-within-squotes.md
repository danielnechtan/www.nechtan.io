'"hello"' he said
