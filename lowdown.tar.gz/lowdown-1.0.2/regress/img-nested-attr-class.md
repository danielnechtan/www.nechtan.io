
link [![text](img.jpg){ .cls }](foo.com){ .cls2 }
