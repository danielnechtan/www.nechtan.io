shift heading level by: -1

# header 1

1

## header 2

2

### header 3

3

#### header 4

4

##### header 5

5
