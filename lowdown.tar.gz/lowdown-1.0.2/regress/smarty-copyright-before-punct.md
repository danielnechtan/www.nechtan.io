foo (c).
