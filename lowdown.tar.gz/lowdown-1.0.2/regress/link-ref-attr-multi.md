a [b][cdef]

[cdef]: foo.com { .class #id some=key }

