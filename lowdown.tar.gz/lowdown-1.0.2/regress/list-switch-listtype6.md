1. a 
   -  b

      c
