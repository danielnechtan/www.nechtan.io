
a [b][cdef]

[cdef]: foo.com "this is a title"

