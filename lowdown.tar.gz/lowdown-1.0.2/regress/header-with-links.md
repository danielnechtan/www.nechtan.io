
# a https://foo.com now [world](https://bar.com) b

c
