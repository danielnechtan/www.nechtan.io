# a {.b .c}

c

a {.b .e}
=======

c
