1. c
-  a
