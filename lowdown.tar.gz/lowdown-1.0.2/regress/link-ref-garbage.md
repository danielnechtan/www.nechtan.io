
a [b][cdef]

[cdef]: foo.com garbage

