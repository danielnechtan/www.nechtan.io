a

- b https://foo.com c
- d e
