
Should be esaped: \<hi /\>. \<hi\>.
