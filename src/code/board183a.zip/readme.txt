####################################
# IMPROVED WWWBOARD 1.83a ('Mr. Fong Device')
# 21 Aug 2000
#
# TODO : update this file :)
#
#===================================
#
# Note for people upgrading from older versions :
#
# You should DELETE your old scripts and reset
# up from scratch.. too many changes for the old
# data files to work properly.
#
#===================================
#
# This script is an improved version of:
# WWWBoard by Matt Wright (see legal stuff below).
#
# Matt's Script is the web's standard WWWBoard script - used on tens of
# thousands of sites on the Net. It is simple, elegant, and intuitive.
# This script is an update of Matt's WWWBoard, with several major
# improvements...
#
# For more details, see the fd_board.cgi script.
#
####################################

Firstly, I accept no liability if this script stuffs things up or causes
your server / profits / person damage. I dont know how it could, but
there ya go.


1/ Make 'wwwboard' and 'wwwboard/messages' directories on da site

2/ ** OPEN fd_board.cgi, fd_admin.cgi and fd_find.cgi in full windows with NO WRAPPING **
   Go thru fd_board.cgi and change the variables to point to your URL.
   If you want, set other variables to how you want them.

3/ Do same in fd_admin.cgi and fd_find.cgi. You can copy some of the configuration
   from fd_board.cgi if you want.

4/ If needed, change location of Perl on the first line of each script
   it may be at /usr/bin/perl on your server.

5/ Upload (as ASCII format) the scripts to the 'wwwboard' dir if possible.

6/ *If* your cgi files have to go in a special place (like 'cgi-bin'), you
   will need to say where they are in the fd_board.cgi and fd_admin.cgi files.
   You will also need to change the ref to the fd_board.cgi and fd_find.cgi scripts
   in index.html.

7/ Upload all the other files to the wwwboard directory. If you want to use
   faq2.html instead of faq.html, simply rename that file to faq.html...

8/ Chmod the cgi scripts to 755 and all the other files to 777. (Your FTP software
   will usually have a feature to let you do this).

9/ Chmod the wwwboard and wwwboard/messages directorys to 777

10/ Chmod index.html to 777.   

11/ You should be able to access the web admin script with username and password both
    "wwwboard". Change this password ASAP.
    If your server uses MD5-encrypted passwords instead of the usual DES crypt (e.g.
    on FreeBSD or the VirtualAve site), you'll have to change the 'my_pass' file first.
    Replace :
wwwboard:aecUU7rxRK4E.
    with :
wwwboard:$1$mj$KfWarrIOmXgNdx7Bhq0Bv.
    and then use the "Change Password" option of fd_admin.cgi to change your password.

12/ You should also change the name of the 'my_pass' file and the ref to it in fd_admin.cgi
    to something else for security reasons (otherwise, someone can just go to
    yoursite.com/mypass and then crack the password with a standard Unix password cracker).

13/ You should also change the name of the 'my_log', 'my_spam' and 'my_ban' files and the refs
    to them in fd_board.cgi, fd_find.cgi and fd_admin.cgi to something else for security
    reasons (otherwise, someone can just go to yoursite.com/my_log and then see all the dirty
    details of who accessed the board, what errors occurred etc.

14/ you may get an error the first time you try a post. just try 1 or 2  more for the data
    files to get going.

    Note : if you know that your webserver will run your scripts under your userID,
    you could use more secure file permissions, like 755 for the directories and scripts,
    644 for the .html and .gif files, or even 600 for the other files.
    If you don't know what I'm talking about here, just do everything as described above :)


* Any bugs or security problems should be posted immediately at:
www.cyberarmy.com/wwwboard
It is a real board running this script.
Do not post 'test' messages there.


Enjoy!
'The Mr.Fong Device' Team,
http://www.cyberarmy.com


